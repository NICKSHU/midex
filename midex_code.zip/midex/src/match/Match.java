package match;

import debtDebit.DebitOrder;
import exchange.Order;

public class Match {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		while(true){
			Order.matching();
			DebitOrder.matching();
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("match");
		}
	}

}
