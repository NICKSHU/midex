package exchange;

import init.Myjedis;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.Set;

import admin.Num;
import create.Create;
import redis.clients.jedis.Jedis;
import remittance.Transfer;

public class Order {
	public static Jedis jedis=Myjedis.getJedis();
	//public static Jedis jedis=new Jedis ("localhost");
	public static String time;
	public static DecimalFormat df=new DecimalFormat("#.00");
	public static int current_time;
	public static String[] time2;
	public static Set<String> set_buy ;
	public static String pre_buy ;
	public static String[] previous_buy;
	public static BigDecimal buy_price;
	public static int buy_time;
	public static BigDecimal buy_amount;
	public static String buy_user_id;
	public static Double buy_score;
	public static Set<String> set_sell ;
	public static String pre_sell;
	public static String[] previous_sell ;
	public static BigDecimal sell_price;
	public static int sell_time;
	public static BigDecimal sell_amount;
	public static String sell_user_id;
	public static Double sell_score;
	public static int note=0;
	
	 
	public static String order_cancel(String key_asset_bs,String transaction_info,String password){
			
		
		/*
		 
		 
				 if (from_after_amount>0){					  
					 for(String user_list_item:user_list){
						 if( jedis.hget(user_list_item, "id").equals(from_id)&&jedis.hget(user_list_item,"password").equals(password) ){
						 note=1;
						 }  }
		 *
		 **/
		//System.out.println("aaa"+jedis.zscore(key_asset_bs, transaction_info));
	     	Set<String> user_list=jedis.keys("user:*"); 
	     	note=0;
	     	
			String[] order_info=transaction_info.split("\\$");
			String[] asset_bs=key_asset_bs.split(":");
			System.out.println(order_info);
			System.out.println(asset_bs);
			String asset_category=asset_bs[0];
			String buy_sell_note=asset_bs[1];
			BigDecimal price=Num.parseString(order_info[0]);
			//String time =order_info[1];
			BigDecimal amount=Num.parseString(order_info[2]);
			String user_id=order_info[3];
			for(String user_list_item:user_list){
				 if( jedis.hget(user_list_item, "id").equals(user_id)&&jedis.hget(user_list_item,"password").equals(password) ){
					 if(jedis.zscore(key_asset_bs, transaction_info) != null)
					 {
						 note=1;
					 }
				 } 
			}
			if(note ==1){
			
		    if(jedis.zscore(key_asset_bs, transaction_info) != null){
			 
			jedis.zrem(key_asset_bs, transaction_info);
			if(buy_sell_note.equals("buy")){
			Transfer.asset_transfer("000", user_id, "midcoin", amount.multiply(price))	;//amount*price
			return "取消订单成功！";
			
			}

			else if(buy_sell_note.equals("sell")){
			Transfer.asset_transfer("000", user_id, asset_category, amount)	;
			return "取消订单成功！";
			}	
			else{
				return "取消订单失败！";
			}
			}	
			}
			else{
				//System.out.println("shib");
				return "取消失败！";
			}
			return "取消失败！";
	}
	
	public static String order_book(
			String user_id , 
			String buy_sell_note , 
		    BigDecimal price ,
			BigDecimal amount,
			String asset_category,
			String password)
	{	
		price =Num.parseString(df.format(price)) ; 
		amount= Num.parseString(new DecimalFormat("#.00").format(amount));
		note = 0;
	    current_time=getCurrentTime();
	    
	    Set<String> user_list=jedis.keys("user:*");
	    Set<String> asset_info_list=jedis.keys("asset_info_id:*");
	   
	    
		if(buy_sell_note.equals("buy")){	
			 for(String user_list_item:user_list){
				if( jedis.hget(user_list_item, "id").equals(user_id)
					&&jedis.hget(user_list_item,"password").equals(password)
					&& amount.compareTo(Num.parseInt(0)) > 0){
			       for(String asset_info_item_o:asset_info_list){
			    		if(jedis.hget(asset_info_item_o, "user_id").equals(user_id)&&
							"midcoin".equals(jedis.hget(asset_info_item_o, "asset_category")))
					{
			    			BigDecimal asset_midcoin_surplus=parseString(jedis.hget(asset_info_item_o,"asset_amount")).subtract(price.multiply(amount));
			    			if(asset_midcoin_surplus.compareTo(parseInt(0))>=0){
			    				note=1;
			    				//jedis.hset(asset_info_item_o,"asset_amount",asset_midcoin_surplus+"");
			    				
			    				
			    				}		
			    			}		
						 }  
					 }
				}
			
			
			if(note==1){
			jedis.zadd(asset_category +
					":" +
					"buy", 
					10000*price.doubleValue()+0.001*(86400-current_time)+0.0001*(1-Math.pow(2, -amount.doubleValue())), 
					price  +
					"$" +
					current_time +
					"$" +
					amount +
					"$" +
					user_id);
			Transfer.asset_transfer(user_id, "000", "midcoin", price.multiply(amount));
			
			//jedis.save();
			return "下单成功！";
			}else{
				System.out.println("下单失败！");
				return "下单失败！";
			}		
		}
		else if(buy_sell_note.equals("sell")){
			for(String user_list_item:user_list){
				if( jedis.hget(user_list_item, "id").equals(user_id)
					&&jedis.hget(user_list_item,"password").equals(password)
					&& amount.compareTo(parseInt(0)) > 0){
			       for(String asset_info_item_o:asset_info_list){
			    		if(jedis.hget(asset_info_item_o, "user_id").equals(user_id)&&
							asset_category.equals(jedis.hget(asset_info_item_o, "asset_category")))
					{		
			    			BigDecimal asset_surplus=parseString(jedis.hget(asset_info_item_o,"asset_amount")).subtract(amount);
			    			if(asset_surplus.compareTo(parseInt(0))>=0){
			    				note=1;
			    				//jedis.hset(asset_info_item_o,"asset_amount",asset_surplus+"");
			    				}			
							}		
						 }  
					 }
				}
			
			
			if(note==1){
			jedis.zadd(asset_category +
					":" +
					"sell", 
					10000*price.doubleValue()+0.001*current_time+0.0001*Math.pow(2, -amount.doubleValue()), 
					price  +
					"$" +
					current_time +
					"$" +
					amount +
					"$" +
					user_id);
			Transfer.asset_transfer(user_id, "000", asset_category, amount);
			
			//jedis.save();
			return "下单成功！";
		}
	}
		else{
			System.out.println("下单失败");
			return "下单失败！";
		}
			
		return "";
	}
	
	
	
	public static void matching (){
		for(String asset_category_item:(Create.asset_category)){
			direct_matching(asset_category_item);	
		}
	}
	
	
	public static void direct_matching (String direct_asset_category){
		
		while(true){
		 set_buy = jedis.zrevrange(direct_asset_category +
		 		":buy", 0, 0); 
		 set_sell = jedis.zrange(direct_asset_category +
			 		":sell", 0, 0); 
		 if(set_buy.size()<1||set_sell.size()<1){
			 
			 break;
		 }
		 
		 
		 pre_buy =set_buy.toArray()[0].toString();
		 previous_buy=pre_buy.split("\\$");
		 buy_price= parseString(previous_buy[0] );
		 buy_time=Integer.parseInt(previous_buy[1]);
		 buy_amount=parseString(previous_buy[2] );
		 buy_user_id=(previous_buy[3] );
		 buy_score=jedis.zscore(direct_asset_category +
		 		":buy", pre_buy);
		
		 pre_sell =set_sell.toArray()[0].toString();
         previous_sell =pre_sell.split("\\$");
         sell_price= parseString(previous_sell[0] );
         sell_time=Integer.parseInt(previous_sell[1]);
         sell_amount=parseString(previous_sell[2] );
		 sell_user_id=(previous_sell[3] );
		 sell_score=jedis.zscore(direct_asset_category +
		 		":sell", pre_sell);
		 
		
		 
		if(buy_price.compareTo(sell_price)<0){
			break;
		}
		else if (buy_price.compareTo(sell_price) ==0){
			if(sell_amount.compareTo(buy_amount)>0){
				jedis.zrem(direct_asset_category +
						":buy", pre_buy);
				jedis.zrem(direct_asset_category +
						":sell", pre_sell);					
				remittance.Transfer.asset_transfer("000", buy_user_id, direct_asset_category, buy_amount);
				remittance.Transfer.asset_transfer("000", sell_user_id, "midcoin", buy_price.multiply(buy_amount));
				sell_amount=sell_amount.subtract(buy_amount);
				jedis.zadd(direct_asset_category +
						":sell",
						sell_score, sell_price  +
						"$" +
						sell_time +
						"$" +
						sell_amount +
						"$" +
						sell_user_id);
				}
				else if(sell_amount.compareTo(buy_amount)==0){
					jedis.zrem(direct_asset_category +
							":buy", pre_buy);
					jedis.zrem(direct_asset_category +
							":sell", pre_sell);
					remittance.Transfer.asset_transfer("000", buy_user_id, direct_asset_category, buy_amount);
					remittance.Transfer.asset_transfer("000", sell_user_id, "midcoin", buy_price.multiply(buy_amount));
					}
		else if(sell_amount.compareTo(buy_amount)<0){
			jedis.zrem(direct_asset_category +
					":buy", pre_buy);
			jedis.zrem(direct_asset_category +
					":sell", pre_sell);
			remittance.Transfer.asset_transfer("000", buy_user_id, direct_asset_category, sell_amount);
			remittance.Transfer.asset_transfer("000", sell_user_id, "midcoin", sell_price.multiply(sell_amount));	
			buy_amount=buy_amount.subtract(sell_amount);
			jedis.zadd(direct_asset_category +
					":buy",
					buy_score, buy_price  +
					"$" +
					buy_time +
					"$" +
					buy_amount +
					"$" +
					buy_user_id);	
			}
		}
		else if (buy_price.compareTo(sell_price)>0){
			BigDecimal price_tr=Num.parseInt(0);		 
			if(buy_time<sell_time){
				price_tr=buy_price;
			}else {
				price_tr=sell_price;
			}
			if(sell_amount.compareTo(buy_amount)>0){
				
				jedis.zrem(direct_asset_category +
						":buy", pre_buy);
				jedis.zrem(direct_asset_category +
						":sell", pre_sell);
				remittance.Transfer.asset_transfer("000", buy_user_id, direct_asset_category, buy_amount);
				remittance.Transfer.asset_transfer("000", sell_user_id, "midcoin", price_tr.multiply(buy_amount));
				sell_amount=sell_amount.subtract(buy_amount);
				jedis.zadd(direct_asset_category +
						":sell",
						sell_score, sell_price  +
						"$" +
					sell_time +
						"$" +
						sell_amount +
						"$" +
						sell_user_id);
				
			}
			else if(sell_amount.compareTo(buy_amount)==0){
				jedis.zrem(direct_asset_category +
						":buy", pre_buy);
				jedis.zrem(direct_asset_category +
						":sell", pre_sell);
				remittance.Transfer.asset_transfer("000", buy_user_id, direct_asset_category, buy_amount);
				remittance.Transfer.asset_transfer("000", sell_user_id, "midcoin", price_tr.multiply(buy_amount));
			}
			else if(sell_amount.compareTo(buy_amount)<0){
				jedis.zrem(direct_asset_category +
						":buy", pre_buy);
				jedis.zrem(direct_asset_category +
						":sell", pre_sell);
				remittance.Transfer.asset_transfer("000", buy_user_id, direct_asset_category, sell_amount);
				remittance.Transfer.asset_transfer("000", sell_user_id, "midcoin", price_tr.multiply(sell_amount));
				
				buy_amount=buy_amount.subtract(sell_amount);
				jedis.zadd(direct_asset_category +
						":buy",
						buy_score, buy_price  +
						"$" +
						previous_buy[1] +
						"$" +
						buy_amount +
						"$" +
						buy_user_id);			
				}
		     }
		
		}
	}
	public static int getCurrentTime(){
		time=new Date().toString().split(" ")[3];
	    time2=time.split(":");
		return Integer.parseInt(time2[0])*3600+60*Integer.parseInt(time2[1])+Integer.parseInt(time2[2]);
	    }
	public static BigDecimal parseString(String s) {
		// TODO Auto-generated method stub

		return new BigDecimal(s);
	}
	public static BigDecimal parseInt(int i) {
		// TODO Auto-generated method stub

		return new BigDecimal(i);
	}
	public static BigDecimal parseDouble(Double d) {
		// TODO Auto-generated method stub

		return new BigDecimal(d);
	}
	public static BigDecimal parseFloat(float f) {
		// TODO Auto-generated method stub

		return new BigDecimal(f);
	}
    }
