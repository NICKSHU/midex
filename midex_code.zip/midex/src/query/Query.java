package query;

import init.Myjedis;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import create.Create;

import redis.clients.jedis.Jedis;

public class Query {
	public static Jedis jedis=Myjedis.getJedis();
	public static Set<String> All_order= new HashSet<String>(); 
	public static Set<String> All_debit_order= new HashSet<String>(); 
	
	
	 
	 
	public static Set<String> query_order(String user_id,String password){
		All_order.clear();
		int note=0;
		Set<String> result= new HashSet<String>(); 
		 
		Set<String> user_list=jedis.keys("user:*"); 
		for(String user_list_item:user_list){
			 if( jedis.hget(user_list_item, "id").equals(user_id)&&jedis.hget(user_list_item,"password").equals(password) ){	 
					 note=1;	  
			 } 
		}
		
		if(note==1){
			
			 
				
				for(String asset:Create.asset_category){
					
					
					for(String item_buy:jedis.zrange(asset +":buy", 0, -1)){
						All_order.add((asset+ ":buy"+"#" +item_buy).toString());	
					}
					 
					for(String item_sell:jedis.zrange(asset +":sell", 0, -1)){
						All_order.add((asset+ ":sell" +	"#" +item_sell).toString());	
					}	
				} 
			
			for(String order_item:All_order){
				
				if(order_item.split("\\$")[3].equals(user_id)){
					result.add(order_item);
				} 
				
				
			}
			return result;
		}
		else{
			return null;
		}
		
	}
	
	
	public static Set<String> query_debit_order(String user_id,String password){
		All_order.clear();
		int note=0;
		Set<String> result= new HashSet<String>(); 
		 
		Set<String> user_list=jedis.keys("user:*"); 
		for(String user_list_item:user_list){
			 if( jedis.hget(user_list_item, "id").equals(user_id)&&jedis.hget(user_list_item,"password").equals(password) ){	 
					 note=1;	  
			 } 
		}
		
		if(note==1){
			

			for(String asset:Create.asset_category){
				for(String item_borrow:jedis.zrange(asset +":borrow", 0, -1)){
					All_order.add((asset+ ":borrow"+"#" +item_borrow).toString());	
				}
				 
				for(String item_lend:jedis.zrange(asset +":lend", 0, -1)){
					All_order.add((asset+ ":lend" +	"#" +item_lend).toString());	
				}
			} 
			
			for(String order_item:All_order){
				
				if(order_item.split("\\$")[3].equals(user_id)){
					result.add(order_item);
				} 
			}
			return result;
		}
		else{
			return null;
		}
		
		
	}
	

	public static String Getprice(){
		 
		StringBuffer sb=new StringBuffer();
		sb.append(" myData = [ ");
		
		for(int i= 0;i<create.Create.asset_category.length;i++){
			//sb.append(asset +":buy"+jedis.zrange(asset +":buy", 0, 0) + asset +":sell"+jedis.zrevrange(asset +":sell", 0, 0));
		//out.println();
		//out.println();
			
			// ['3m Co',  71.7200001,'---',1,1],
			sb.append("['"+create.Create.asset_category[i].toUpperCase()+"',");
			String[] buy=jedis.zrevrange(create.Create.asset_category[i] +":buy", 0, 0).toString().split("\\$");
			
			
			if(buy.length<3){
			sb.append( "'---','---',");
			}else{
			sb.append( ""+buy[0].replace("[", "")  +","+buy[2]+",");
			}
			
			//System.out.println(buy[2]);
			
			String[] sell=jedis.zrange(create.Create.asset_category[i] +":sell", 0, 0).toString().split("\\$");
			
			//sb.append(create.Create.asset_category[i] +" / midcoin SELL"+"<BR/>");
			if(sell.length<3){
				sb.append( "'---','---',");
			}
			else{
				sb.append(""+sell[0].replace("[", "") +","+sell[2]+",");
			}
			
			
			//sb.append(",");
			String[] borrow=jedis.zrevrange(create.Create.asset_category[i] +":borrow", 0, 0).toString().split("\\$");
			
			
			if(borrow.length<3){
			sb.append( "'---','---',");
			}else{
			sb.append( ""+borrow[0].replace("[", "")  +","+borrow[2]+",");
			}
			
			//System.out.println(buy[2]);
			
			String[] lend=jedis.zrange(create.Create.asset_category[i] +":lend", 0, 0).toString().split("\\$");
			
			//sb.append(create.Create.asset_category[i] +" / midcoin SELL"+"<BR/>");
			if(lend.length<3){
				sb.append( "'---','---',");
			}
			else{
				sb.append(""+lend[0].replace("[", "") +","+lend[2]+",");
			}
 
			sb.append( "],");
		}
			
			
		sb.append(" ];");
		 
		return sb.toString();
		 
	}

	
}
