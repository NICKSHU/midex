package query;

import init.Myjedis;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import redis.clients.jedis.Jedis;

public class Price extends HttpServlet {

	Jedis jedis=Myjedis.getJedis();
 
	/**
	 * Constructor of the object.
	 */
	public Price() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); 
	}

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		 this.doPost(request, response);
		 
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out= response.getWriter();
		
		
		/*
		 
		 response.setContentType("text/html;charset=GBK");
		 PrintWriter out = response.getWriter(); 
		 * */
		StringBuffer sb=new StringBuffer();
		
		for(int i= 1;i<create.Create.asset_category.length;i++){
			//sb.append(asset +":buy"+jedis.zrange(asset +":buy", 0, 0) + asset +":sell"+jedis.zrevrange(asset +":sell", 0, 0));
		//out.println();
		//out.println();
			sb.append(create.Create.asset_category[i].toUpperCase() +" / MIDCOIN 买方/卖方"+"<BR/>");
			String[] buy=jedis.zrevrange(create.Create.asset_category[i] +":buy", 0, 0).toString().split("\\$");
			
			
			if(buy.length<3){
			sb.append( "------"+"<br/>");
			}else{
			sb.append( "买一 价格 "+buy[0].replace("[", "")  +"   数量:"+buy[2]+"<BR/>  ");
			}
			
			//System.out.println(buy[2]);
			
			String[] sell=jedis.zrange(create.Create.asset_category[i] +":sell", 0, 0).toString().split("\\$");
			
			//sb.append(create.Create.asset_category[i] +" / midcoin SELL"+"<BR/>");
			if(sell.length<3){
				sb.append( "------"+"<BR/> <HR/>");
			}
			else{
				sb.append("卖一 价格 "+sell[0].replace("[", "") +"   数量:"+sell[2]+"<BR/> <HR/>");
			}
			
		}
			
			
		for(int i= 0;i<create.Create.asset_category.length;i++){
			
			sb.append(create.Create.asset_category[i].toUpperCase() +"  借入/贷出"+"<BR/>");
			String[] borrow=jedis.zrevrange(create.Create.asset_category[i] +":borrow", 0, 0).toString().split("\\$");
			
			
			if(borrow.length<3){
			sb.append( "------"+"<BR/>  ");
			}else{
			sb.append( "借一 利息率（%）:"+borrow[0].replace("[", "")  +"   数量:"+borrow[2]+"<BR/>  ");
			}
			
			//System.out.println(buy[2]);
			
			String[] lend=jedis.zrange(create.Create.asset_category[i] +":lend", 0, 0).toString().split("\\$");
			
			//sb.append(create.Create.asset_category[i] +" / midcoin SELL"+"<BR/>");
			if(lend.length<3){
				sb.append( "------"+"<BR/> <HR/>");
			}
			else{
				sb.append("贷一 利息率（%）:"+lend[0].replace("[", "") +"    数量:"+lend[2]+"<BR/> <HR/>");
			}
 
			
		}
		 
		out.println(sb);
	}

	
	public void init() throws ServletException {
		// Put your code here
	}

}
