package init;

import java.util.Set;

public class Data {

	
	public static Set<String> user_list;
	public static Set<String> asset_info_list;
	
	
	static{
		 user_list=Myjedis.getJedis().keys("user:*"); 
		asset_info_list=Myjedis.getJedis().keys("asset_info_id:*");
	}
	/**
	 * @param args
	 */
	 
}
