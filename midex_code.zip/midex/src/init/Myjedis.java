package init;

import redis.clients.jedis.Jedis;

public class Myjedis {

	  
	    private static Jedis jedis = new Jedis();  
	    private Myjedis(){}  
	    public static Jedis getJedis(){ 
	    	//连接redis服务器，192.168.0.100:6379
	        //jedis对象实例化两种方式
	        jedis = new Jedis("localhost", 6379);//jedis = RedisClient.getResource();
	        //权限认证
	        //jedis.auth("hunn1234"); 
	        jedis.select(0);
	        return jedis;  
	    }  
}
