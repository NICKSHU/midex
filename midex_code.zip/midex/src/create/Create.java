package create;

import init.Myjedis;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import redis.clients.jedis.Jedis;

public class Create {

	/**
	 * @param args
	 */
	public static String[] asset_category={"midcoin","bitcoin","usd","ethereum","cny","hkd","ntd","iota","euro"};
	public static Jedis jedis=Myjedis.getJedis();
	public static int note;
	 
	public static void create(){
		jedis.flushAll(); //1
		
		
		create_id(); //2
		create_user("system", "hunn1234", "系统用户", "000","10000000000");
		/*create_user("xx","nick","email","1","0");
		create_user("xx","nick","email","2","0");
		create_user("xx","nick","email","3","0");
		create_user("xx","nick","email","4","0");*/
		jedis.save();
	}

	public static void create_id(){
		jedis.set("user_id", "1");
		jedis.set("asset_info_id", "1");
		 
		
	}
	public static void create_user(
			String name,
			String password,
			String email,
			String id,
			String asset_balance)
	{
		note=0;
		Set<String> user_list=jedis.keys("user:*");
		for(String user_list_item:user_list){
			if(jedis.hget(user_list_item, "id").equals(id)||id.trim().equals("")){
				note=1;
			}
		}
		if(note==1){
			
			System.out.println("id已经存在");
			return;
			
		}	
		else{
		Map<String,String> user=new HashMap<String,String>();
		user.put("name", name);
		user.put("password", password);
		user.put("id", id);
		user.put("email", email);
		jedis.hmset("user:" + jedis.get("user_id"), user);
		jedis.incr("user_id");
		
		for(String asset_category_item:asset_category)
		{
			
			Map<String,String> asset_info=new HashMap<String,String>();
			asset_info.put("user_id", id);
			asset_info.put("asset_category",asset_category_item );
			asset_info.put("asset_amount", asset_balance);
			asset_info.put("debt_amount", "0");
			asset_info.put("credit_amount", "0");
			asset_info.put("mortgage_amount", "0");
			jedis.hmset("asset_info_id:" + jedis.get("asset_info_id"), asset_info);
			jedis.incr("asset_info_id");

		                  }
		            }
               	}
	   
           }