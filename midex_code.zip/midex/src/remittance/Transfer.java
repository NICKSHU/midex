package remittance;

import init.Myjedis;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;



import admin.Num;

import redis.clients.jedis.Jedis;

public class Transfer {
	
	public static BigDecimal from_pre_amount;
	public static BigDecimal from_after_amount;
	public static int note=0;
	public static Jedis jedis=Myjedis.getJedis();
	public static void main(String[] args) {
	//	asset_transfer("1", "2", "bitcoin", -20,"nick");
	}
	
	public static String asset_transfer(String from_id,String to_id,
			String asset_category,BigDecimal amount,String password)
	{
		 
		Set<String> asset_info_list=jedis.keys("asset_info_id:*");
		note = 0;
		for(String asset_info_item_o:asset_info_list){
			if(jedis.hget(asset_info_item_o, "user_id").equals(from_id)&&
					asset_category.equals(jedis.hget(asset_info_item_o, "asset_category"))
					&&amount.compareTo(Num.parseInt(0))>0){
				 from_pre_amount=Num.parseString(jedis.hget(asset_info_item_o, "asset_amount"));
				 from_after_amount=(from_pre_amount .subtract(amount) );
				 Set<String> user_list=jedis.keys("user:*"); 
				 if (from_after_amount.compareTo(Num.parseInt(0))>0){					  
					 for(String user_list_item:user_list){
						 if( jedis.hget(user_list_item, "id").equals(from_id)&&jedis.hget(user_list_item,"password").equals(password) ){
						 
							 
							 for(String user_list_item_o:user_list){
							 
							 if( jedis.hget(user_list_item_o, "id").equals(to_id)){
							 
							        note=1;
							     }
							   }
						 }  }
				    } 
				 }
		}
		if(note==0){
			
			return "用户不存在密码错误或者账户余额不足";
		}else{
		for(String asset_info_item:asset_info_list){
			if(jedis.hget(asset_info_item, "user_id").equals(from_id)&&
					asset_category.equals(jedis.hget(asset_info_item, "asset_category")))
			
			{
				 from_pre_amount=Num.parseString(jedis.hget(asset_info_item, "asset_amount"));
				 from_after_amount=(from_pre_amount .subtract(amount) );
				jedis.hset(asset_info_item, "asset_amount", from_after_amount+"");
			}
			if(jedis.hget(asset_info_item, "user_id").equals(to_id)&&
					asset_category.equals(jedis.hget(asset_info_item, "asset_category")))
			
			{
				 from_pre_amount=Num.parseString(jedis.hget(asset_info_item, "asset_amount"));
				 from_after_amount=(from_pre_amount .add(amount) );
				jedis.hset(asset_info_item, "asset_amount", from_after_amount+"");
			}
			
			
			
		
		        } 
	       }
		
		Date date =  new  java.util.Date ();
        String key=date.getYear()+1900+""+(date.getMonth()+1)+""+date.getDate();
        
        if(!jedis.exists("transaction"+key)){
        	jedis.set("transaction"+key,"");
        }

        jedis.set("transaction"+key, jedis.get("transaction"+key)+"{asset:" +	asset_category +	",amount:" +	
        amount +	",from:" +	Arrays.hashCode(new String[]{from_id}) +		",to:" +	Arrays.hashCode(new String[]{to_id}) +   		"}");
        
        System.out.println(jedis.get("transaction"+key));
        
        

        List< String[]> Transactions= new ArrayList<String[]>();
        
        
        
        Set<String>transactionkey= jedis.keys("transaction*");
        
        for(String tk:transactionkey){
        	 Transactions.add(new String[]{jedis.get(tk)});
        	System.out.println(jedis.get(tk));
        }
  
        List<Block>  block= new ArrayList<Block>();       
        block.add(new Block(0, Transactions.get(0)));
        int i=0;
        for (i=0;i<Transactions.size()-1;i++){
        	block.add(new Block(block.get(i).getBlockHash(),Transactions.get(i+1)));
        	
        }
       
        System.out.println(block.get(i).getBlockHash());
        jedis.set("check",Integer.toString(block.get(i).getBlockHash()) );
        
        
		
		jedis.save();
		 return "转账成功";
		}
	
	
	
	public static void asset_transfer(String from_id,String to_id,
			String asset_category,BigDecimal amount)
	{
		//Jedis jedis=Myjedis.getJedis();
		Set<String> asset_info_list=jedis.keys("asset_info_id:*");
		for(String asset_info_item:asset_info_list){
			if(jedis.hget(asset_info_item, "user_id").equals(from_id)&&
					asset_category.equals(jedis.hget(asset_info_item, "asset_category")))
			
			{
				 from_pre_amount=Num.parseString(jedis.hget(asset_info_item, "asset_amount"));
				 from_after_amount=(from_pre_amount .subtract(amount) );
				jedis.hset(asset_info_item, "asset_amount", from_after_amount+"");
			}
			if(jedis.hget(asset_info_item, "user_id").equals(to_id)&&
					asset_category.equals(jedis.hget(asset_info_item, "asset_category")))
			
			{
				 from_pre_amount=Num.parseString(jedis.hget(asset_info_item, "asset_amount"));
				 from_after_amount=(from_pre_amount .add(amount) );
				jedis.hset(asset_info_item, "asset_amount", from_after_amount+"");
			}
			
			
			
			
			
		
		} 
		
		Date date =  new  java.util.Date ();
        String key=date.getYear()+1900+""+(date.getMonth()+1)+""+date.getDate();
        
        if(!jedis.exists("transaction"+key)){
        	jedis.set("transaction"+key,"");
        }

        jedis.set("transaction"+key, jedis.get("transaction"+key)+"{asset:" +	asset_category +	",amount:" +	
        amount +	",from:" +	Arrays.hashCode(new String[]{from_id}) +		",to:" +	Arrays.hashCode(new String[]{to_id}) +   		"}");
        
        System.out.println(jedis.get("transaction"+key));
        
        

        List< String[]> Transactions= new ArrayList<String[]>();
        
        
        
        Set<String>transactionkey= jedis.keys("transaction*");
        
        for(String tk:transactionkey){
        	 Transactions.add(new String[]{jedis.get(tk)});
        	System.out.println(jedis.get(tk));
        }
  
        List<Block>  block= new ArrayList<Block>();       
        block.add(new Block(0, Transactions.get(0)));
        int i=0;
        for (i=0;i<Transactions.size()-1;i++){
        	block.add(new Block(block.get(i).getBlockHash(),Transactions.get(i+1)));
        	
        }
       
        System.out.println(block.get(i).getBlockHash());
        jedis.set("check",Integer.toString(block.get(i).getBlockHash()) );
        
        
		
		jedis.save();
		
		
	}

}
