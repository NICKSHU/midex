package debtDebit;

import init.Myjedis;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.Set;

import admin.Num;

import redis.clients.jedis.Jedis;
import remittance.Transfer;
import create.Create;

public class DebitOrder {

	public static Jedis jedis=Myjedis.getJedis();
	//public static Jedis jedis=new Jedis ("localhost");
	public static String time;
	public static DecimalFormat df=new DecimalFormat("#.00");
	public static int current_time;
	public static String[] time2;
	public static Set<String> set_borrow ;
	public static String pre_borrow ;
	public static String[] previous_borrow;
	public static BigDecimal borrow_interest;
	public static int borrow_time;
	public static BigDecimal borrow_amount;
	public static String borrow_user_id;
	public static Double borrow_score;
	public static Set<String> set_lend ;
	public static String pre_lend;
	public static String[] previous_lend ;
	public static BigDecimal lend_interest;
	public static int lend_time;
	public static BigDecimal lend_amount;
	public static String lend_user_id;
	public static Double lend_score;
	public static int note=0;
	public static Set<String> asset_info_list;
	public static Set<String> user_list;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String[] aso="bitcoin:borrow#5.0$55260$10.0$123".split("#");
		System.out.println(aso[1]);
		
		//matching();
		// TODO Auto-generated method stub
	//	debit_order_book("000", "lend", 10, "bitcoin", "hunn1234", 5);
		//debit_order_book(user_id, borrow_lend_note, amount, asset_category, password, interest);
		//debit_order_book("000", "lend", 10, "bitcoin", "hunn1234", 5);
		//debit_order_cancel("bitcoin:borrow", "5.0$54070$10.0$123", "123");
		//bitcoin:borrow#5.0$54070$10.0$123

	}
public static String debit_order_cancel(String key_asset_bs,String transaction_info,String password){
			
		 
	     	user_list=jedis.keys("user:*"); 
	     	note=0;
	     	
			String[] order_info=transaction_info.split("\\$");
			String[] asset_bs=key_asset_bs.split(":");
			System.out.println(order_info);
			System.out.println(asset_bs);
			String asset_category=asset_bs[0];
			String borrow_lend_note=asset_bs[1];
			BigDecimal interest=Num.parseString(order_info[0]);
			//String time =order_info[1];
			BigDecimal amount=Num.parseString(order_info[2]);
			String user_id=order_info[3];
			for(String user_list_item:user_list){
				 if( jedis.hget(user_list_item, "id").equals(user_id)&&jedis.hget(user_list_item,"password").equals(password) ){
					 if(jedis.zscore(key_asset_bs, transaction_info) != null)
					 {
						 note=1;
					 }
				 } 
			}
			if(note ==1){
			
		    if(jedis.zscore(key_asset_bs, transaction_info) != null){
			 
			jedis.zrem(key_asset_bs, transaction_info);
			if(borrow_lend_note.equals("borrow")){
			Transfer.asset_transfer("000", user_id, asset_category, amount.multiply(interest).divide(Num.parseInt(100)))	;
			//Transfer.asset_transfer("000", user_id, asset_category, amount*interest/100.0)	;
			return "取消借入订单成功！";
			
			}

			else if(borrow_lend_note.equals("lend")){
			Transfer.asset_transfer("000", user_id, asset_category, amount)	;
			return "取消贷出订单成功！";
			}	
			else{
				return "取消借贷订单失败！";
			}
			}	
			}
			else{
				//System.out.println("shib");
				return "取消借贷订单失败！";
			}
			return "取消借贷订单失败！";
	}
	
	public static String debit_order_book(
			String user_id , 
			String borrow_lend_note ,   
			BigDecimal amount,
			String asset_category,
			String password,
			BigDecimal interest)
	{	
		interest =Num.parseString (df.format(interest)) ; 
		amount= Num.parseString(new DecimalFormat("#.00").format(amount));
		note = 0;
	    current_time=getCurrentTime();
	    
	     user_list=jedis.keys("user:*");
	     asset_info_list=jedis.keys("asset_info_id:*");
	   
	    
		if(borrow_lend_note.equals("borrow")){	
			 for(String user_list_item:user_list){
				if( jedis.hget(user_list_item, "id").equals(user_id)
					&&jedis.hget(user_list_item,"password").equals(password)
					&& (amount.compareTo(Num.parseInt(0)) > 0)	
							){
			       for(String asset_info_item_o:asset_info_list){
			    		if(jedis.hget(asset_info_item_o, "user_id").equals(user_id)&&
							asset_category.equals(jedis.hget(asset_info_item_o, "asset_category")))
					{
			    			BigDecimal asset_surplus=Num.parseString(jedis.hget(asset_info_item_o,"asset_amount")).subtract( interest.divide(Num.parseInt(100).multiply(amount)) );
			    		//	BigDecimal asset_surplus=BigDecimal.parseBigDecimal(jedis.hget(asset_info_item_o,"asset_amount"))-interest/100.0*amount;
			    			if(asset_surplus.compareTo(Num.parseInt(0))>=0){
			    				//asset_surplus>=0
			    				note=1;
			    			 
			    				}		
			    			}		
						 }  
					 }
				}
			//parseInt(100)
			
			if(note==1){
				Transfer.asset_transfer(user_id, "000", asset_category, interest.divide(Num.parseInt(100).multiply(amount)));
				System.out.println( interest.divide(Num.parseInt(100).multiply(amount)));
			jedis.zadd(asset_category +
					":" +
					"borrow", 
					10000*interest.doubleValue()+0.001*(86400-current_time)+0.0001*(1-Math.pow(2, -amount.doubleValue())), 
					interest  +
					"$" +
					current_time +
					"$" +
					amount +
					"$" +
					user_id);
			
			
			jedis.save();
			return "下单成功！";
			}else{
				System.out.println("下单失败！");
				return "下单失败！";
			}		
		}
		else if(borrow_lend_note.equals("lend")){
			for(String user_list_item:user_list){
				if( jedis.hget(user_list_item, "id").equals(user_id)
					&&jedis.hget(user_list_item,"password").equals(password)
					&& amount.compareTo(Num.parseInt(0)) > 0){
			       for(String asset_info_item_o:asset_info_list){
			    		if(jedis.hget(asset_info_item_o, "user_id").equals(user_id)&&
							asset_category.equals(jedis.hget(asset_info_item_o, "asset_category")))
					{		
			    			BigDecimal asset_surplus= Num.parseString(jedis.hget(asset_info_item_o,"asset_amount")).subtract(amount);
			    			//BigDecimal asset_surplus=BigDecimal.parseBigDecimal(jedis.hget(asset_info_item_o,"asset_amount"))-amount;
			    			if(asset_surplus.compareTo(Num.parseInt(0))>=0){
			    				note=1;
			    				//jedis.hset(asset_info_item_o,"asset_amount",asset_surplus+"");
			    				}			
							}		
						 }  
					 }
				}
			
			
			if(note==1){
			jedis.zadd(asset_category +
					":" +
					"lend", 
					10000*interest.doubleValue()+0.001*current_time+0.0001*Math.pow(2, -amount.doubleValue()), 
					interest  +
					"$" +
					current_time +
					"$" +
					amount +
					"$" +
					user_id);
			Transfer.asset_transfer(user_id, "000", asset_category, amount);
			
			jedis.save();
			return "下单成功！";
		}
	}
		else{
			System.out.println("下单失败");
			return "下单失败！";
		}
			
		return "";
	}
	
	
	
	public static void matching (){
		for(String asset_category_item:(Create.asset_category)){
			debit_direct_matching(asset_category_item);	
		}
	}
	
	
	public static void debit_direct_matching (String direct_asset_category){
		
		while(true){
		 set_borrow = jedis.zrevrange(direct_asset_category +
		 		":borrow", 0, 0); 
		 set_lend = jedis.zrange(direct_asset_category +
			 		":lend", 0, 0); 
         if(set_borrow.size()<1||set_lend.size()<1){
			 
			 break;
		 }
		 pre_borrow =set_borrow.toArray()[0].toString();
		 previous_borrow=pre_borrow.split("\\$");
		 borrow_interest= Num.parseString(previous_borrow[0] );
		 borrow_time=Integer.parseInt(previous_borrow[1]);
		 borrow_amount=Num.parseString(previous_borrow[2] );
		 borrow_user_id=(previous_borrow[3] );
		 borrow_score=jedis.zscore(direct_asset_category +
		 		":borrow", pre_borrow);
		 
		 pre_lend =set_lend.toArray()[0].toString();
         previous_lend =pre_lend.split("\\$");
         lend_interest= Num.parseString(previous_lend[0] );
         lend_time=Integer.parseInt(previous_lend[1]);
         lend_amount=Num.parseString(previous_lend[2] );
		 lend_user_id=(previous_lend[3] );
		 lend_score=jedis.zscore(direct_asset_category +
		 		":lend", pre_lend);
		 
		
		 
		if(borrow_interest.compareTo(lend_interest)<0){
			//borrow_interest<lend_interest
			break;
		}
		else if (borrow_interest.compareTo(lend_interest)==0 ){
			if(lend_amount.compareTo(borrow_amount)>0){
				jedis.zrem(direct_asset_category +
						":borrow", pre_borrow);
				jedis.zrem(direct_asset_category +
						":lend", pre_lend);	
				
				
				
				remittance.Transfer.asset_transfer("000", borrow_user_id, direct_asset_category, borrow_amount);
				remittance.Transfer.asset_transfer("000", lend_user_id, direct_asset_category,borrow_interest.divide(Num.parseInt(100)).multiply(borrow_amount) );//borrow_interest/100.0*borrow_amount
				
				  asset_info_list=jedis.keys("asset_info_id:*");
				for(String asset:asset_info_list){ 
					if(jedis.hget(asset, "user_id").equals(lend_user_id)&&jedis.hget(asset, "asset_category").equals(direct_asset_category)){ 
						//Transfer.asset_transfer(user_id, "000", asset_category, amount);
						jedis.hset(asset, "credit_amount",
						(Num.parseString(jedis.hget(asset, "credit_amount")).add(borrow_amount)) +"" );
						 
					}
					if(jedis.hget(asset, "user_id").equals(borrow_user_id)&&jedis.hget(asset, "asset_category").equals(direct_asset_category)){
						
						jedis.hset(asset, "debt_amount",
								(Num.parseString(jedis.hget(asset, "debt_amount")).add(borrow_amount)) +"" );
					}
				}
				
				
				
				
				lend_amount=lend_amount.subtract(borrow_amount);
				jedis.zadd(direct_asset_category +
						":lend",
						lend_score, lend_interest  +
						"$" +
						lend_time +
						"$" +
						lend_amount +
						"$" +
						lend_user_id);
				}
				else if(lend_amount.compareTo(borrow_amount)==0){
					jedis.zrem(direct_asset_category +
							":borrow", pre_borrow);
					jedis.zrem(direct_asset_category +
							":lend", pre_lend);
					
					//remittance.Transfer.asset_transfer("000", borrow_user_id, direct_asset_category, borrow_amount);
					
					
					remittance.Transfer.asset_transfer("000", borrow_user_id, direct_asset_category, borrow_amount);
					remittance.Transfer.asset_transfer("000", lend_user_id, direct_asset_category, borrow_interest.divide(Num.parseInt(100)).multiply(borrow_amount));
					//borrow_interest/100.0*borrow_amount
					
					  asset_info_list=jedis.keys("asset_info_id:*");
					for(String asset:asset_info_list){ 
						if(jedis.hget(asset, "user_id").equals(lend_user_id)&&jedis.hget(asset, "asset_category").equals(direct_asset_category)){ 
							//Transfer.asset_transfer(user_id, "000", asset_category, amount);
							jedis.hset(asset, "credit_amount",
							(Num.parseString(jedis.hget(asset, "credit_amount")).add(borrow_amount)) +"" );
							 
						}
						if(jedis.hget(asset, "user_id").equals(borrow_user_id)&&jedis.hget(asset, "asset_category").equals(direct_asset_category)){
							
							jedis.hset(asset, "debt_amount",
									(Num.parseString(jedis.hget(asset, "debt_amount")).add(borrow_amount)) +"" );
						}
					}
					
					
					
					
				 
					
				
				}
		else if(lend_amount.compareTo(borrow_amount)<0){
			jedis.zrem(direct_asset_category +
					":borrow", pre_borrow);
			jedis.zrem(direct_asset_category +
					":lend", pre_lend);
			remittance.Transfer.asset_transfer("000", borrow_user_id, direct_asset_category, lend_amount);
			remittance.Transfer.asset_transfer("000", lend_user_id, direct_asset_category,lend_interest.divide(Num.parseInt(100)).multiply(lend_amount) );	//lend_interest/100.0*lend_amount
			

			  asset_info_list=jedis.keys("asset_info_id:*");
			for(String asset:asset_info_list){ 
				if(jedis.hget(asset, "user_id").equals(lend_user_id)&&jedis.hget(asset, "asset_category").equals(direct_asset_category)){ 
					//Transfer.asset_transfer(user_id, "000", asset_category, amount);
					jedis.hset(asset, "credit_amount",
					(Num.parseString(jedis.hget(asset, "credit_amount")).add(lend_amount)) +"" );
					 
				}
				if(jedis.hget(asset, "user_id").equals(borrow_user_id)&&jedis.hget(asset, "asset_category").equals(direct_asset_category)){
					
					jedis.hset(asset, "debt_amount",
							(Num.parseString(jedis.hget(asset, "debt_amount")).add(lend_amount)) +"" );
				}
			}
			
			borrow_amount=borrow_amount.subtract(lend_amount);
			
			jedis.zadd(direct_asset_category +
					":borrow",
					borrow_score, borrow_interest  +
					"$" +
					borrow_time +
					"$" +
					borrow_amount +
					"$" +
					borrow_user_id);	
			}
		}
		else if (borrow_interest.compareTo(lend_interest)>0){
			BigDecimal interest_tr=Num.parseInt(0);		 
			if(borrow_time<lend_time){
				interest_tr=borrow_interest;
			}else {
				interest_tr=lend_interest;
			}
			if(lend_amount.compareTo(borrow_amount)>0){
				//lend_amount>borrow_amount
				jedis.zrem(direct_asset_category +
						":borrow", pre_borrow);
				jedis.zrem(direct_asset_category +
						":lend", pre_lend);
				remittance.Transfer.asset_transfer("000", borrow_user_id, direct_asset_category, borrow_amount);
				remittance.Transfer.asset_transfer("000", lend_user_id, direct_asset_category,interest_tr.divide(Num.parseInt(100)).multiply(borrow_amount) );
				//interest_tr/100.0*borrow_amount
				  asset_info_list=jedis.keys("asset_info_id:*");
				for(String asset:asset_info_list){ 
					if(jedis.hget(asset, "user_id").equals(lend_user_id)&&jedis.hget(asset, "asset_category").equals(direct_asset_category)){ 
						//Transfer.asset_transfer(user_id, "000", asset_category, amount);
						jedis.hset(asset, "credit_amount",
						(Num.parseString(jedis.hget(asset, "credit_amount")).add(borrow_amount) +"" ));
						 
					}
					if(jedis.hget(asset, "user_id").equals(borrow_user_id)&&jedis.hget(asset, "asset_category").equals(direct_asset_category)){
						
						jedis.hset(asset, "debt_amount",
								(Num.parseString(jedis.hget(asset, "debt_amount")).add(borrow_amount) +"" ));
					}
				}
				
				
				
				
				lend_amount=lend_amount.subtract(borrow_amount);
				jedis.zadd(direct_asset_category +
						":lend",
						lend_score, lend_interest  +
						"$" +
					lend_time +
						"$" +
						lend_amount +
						"$" +
						lend_user_id);
				
			}
			else if(lend_amount.compareTo(borrow_amount)==0){
				jedis.zrem(direct_asset_category +
						":borrow", pre_borrow);
				jedis.zrem(direct_asset_category +
						":lend", pre_lend);
				remittance.Transfer.asset_transfer("000", borrow_user_id, direct_asset_category, borrow_amount);
				remittance.Transfer.asset_transfer("000", lend_user_id, direct_asset_category,interest_tr.divide(Num.parseInt(100)).multiply(borrow_amount));// /100.0*borrow_amount
				  asset_info_list=jedis.keys("asset_info_id:*");
				for(String asset:asset_info_list){ 
					if(jedis.hget(asset, "user_id").equals(lend_user_id)&&jedis.hget(asset, "asset_category").equals(direct_asset_category)){ 
						//Transfer.asset_transfer(user_id, "000", asset_category, amount);
						jedis.hset(asset, "credit_amount",
						(Num.parseString(jedis.hget(asset, "credit_amount")).add(borrow_amount)) +"" );
						 
					}
					if(jedis.hget(asset, "user_id").equals(borrow_user_id)&&jedis.hget(asset, "asset_category").equals(direct_asset_category)){
						
						jedis.hset(asset, "debt_amount",
								(Num.parseString(jedis.hget(asset, "debt_amount")).add(borrow_amount)) +"" );
					}
				}
				
			
			
			
			
			
			}
			else if(lend_amount.compareTo(borrow_amount)<0){
				jedis.zrem(direct_asset_category +
						":borrow", pre_borrow);
				jedis.zrem(direct_asset_category +
						":lend", pre_lend);
				remittance.Transfer.asset_transfer("000", borrow_user_id, direct_asset_category, lend_amount);
				remittance.Transfer.asset_transfer("000", lend_user_id, direct_asset_category, interest_tr.divide(Num.parseInt(100)).multiply(lend_amount));//interest_tr/100.0*lend_amount
				  asset_info_list=jedis.keys("asset_info_id:*");
				for(String asset:asset_info_list){ 
					if(jedis.hget(asset, "user_id").equals(lend_user_id)&&jedis.hget(asset, "asset_category").equals(direct_asset_category)){ 
						//Transfer.asset_transfer(user_id, "000", asset_category, amount);
						jedis.hset(asset, "credit_amount",
						(Num.parseString(jedis.hget(asset, "credit_amount")).add(lend_amount)) +"" );
						 
					}
					if(jedis.hget(asset, "user_id").equals(borrow_user_id)&&jedis.hget(asset, "asset_category").equals(direct_asset_category)){
						
						jedis.hset(asset, "debt_amount",
								(Num.parseString(jedis.hget(asset, "debt_amount")).add(lend_amount)) +"" );
					}
				}
				
				borrow_amount=borrow_amount.subtract(lend_amount);
				jedis.zadd(direct_asset_category +
						":borrow",
						borrow_score, borrow_interest  +
						"$" +
						previous_borrow[1] +
						"$" +
						borrow_amount +
						"$" +
						borrow_user_id);			
				}
		     }
		
		}
	}
	public static int getCurrentTime(){
		time=new Date().toString().split(" ")[3];
	    time2=time.split(":");
		return Integer.parseInt(time2[0])*3600+60*Integer.parseInt(time2[1])+Integer.parseInt(time2[2]);
	    }
}
