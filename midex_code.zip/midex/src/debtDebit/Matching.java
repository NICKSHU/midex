package debtDebit;

import init.Myjedis;

import java.math.BigDecimal;
import java.util.Set;

import admin.Num;

import redis.clients.jedis.Jedis;
import remittance.Transfer;

public class Matching {

	/**
	 * @param args
	 */
	public static int note;
	public static Jedis jedis;
	 
	
	
	public static String add_mortgage(String user_id,String password,String asset_category,BigDecimal amount){
		
		//验证密码
		note=0;
		jedis=Myjedis.getJedis();
		Set<String> user_list=jedis.keys("user:*"); 
		for(String user_list_item:user_list){
			 if( jedis.hget(user_list_item, "id").equals(user_id)&&jedis.hget(user_list_item,"password").equals(password) &&amount.compareTo(Num.parseInt(0))>0){	 
					 note=1;	  
			 } 
		}
		if(note==1){
			Set<String> asset_info_list=jedis.keys("asset_info_id:*");
			for(String asset:asset_info_list){ 
				if(jedis.hget(asset, "user_id").equals(user_id)&&jedis.hget(asset, "asset_category").equals(asset_category)){ 
					Transfer.asset_transfer(user_id, "000", asset_category, amount);
					jedis.hset(asset, "mortgage_amount",
					(Num.parseString(jedis.hget(asset, "mortgage_amount")).add(amount)) +"" );
					return "抵押成功！";
				}
			}
			return "错误";
			
		} 
		else{
			 return "质押错误！";	
		}
		 
	}
	
	
    public static String cancel_mortgage(String user_id,String password,String asset_category,BigDecimal amount){
		
    	
		//验证密码
		note=0;
		jedis=Myjedis.getJedis();
		Set<String> user_list=jedis.keys("user:*"); 
		for(String user_list_item:user_list){
			 if( jedis.hget(user_list_item, "id").equals(user_id)&&jedis.hget(user_list_item,"password").equals(password) &&amount.compareTo(Num.parseInt(0))>0){	 
					 note=1;	  
			 } 
		}
		if(note==1){
			
			
			
			Set<String> asset_info_list=jedis.keys("asset_info_id:*");
			for(String asset:asset_info_list){ 
				if(jedis.hget(asset, "user_id").equals(user_id)&&jedis.hget(asset, "asset_category").equals(asset_category)){ 
					BigDecimal balance =Num.parseString(jedis.hget(asset, "mortgage_amount")).subtract(amount) ;
					if(balance.compareTo(Num.parseInt(0)) >=0){
						Transfer.asset_transfer("000", user_id, asset_category, amount);
						jedis.hset(asset, "mortgage_amount",
						 balance +"" );
						return "取消抵押成功！";
					}
					
					
					return "错误！";
					
					
				}
			}
			return "错误";
			
		} 
		else{
			 return "错！";	
		}
		 
	}
	

}
