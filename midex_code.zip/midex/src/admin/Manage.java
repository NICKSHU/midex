package admin;

public class Manage {

	/**
	 * @param args
	 */
 
	 
}
