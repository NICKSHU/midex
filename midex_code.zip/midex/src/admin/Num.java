package admin;

import java.math.BigDecimal;

public class Num {

	/**
	 * @param args
	 */
	public static BigDecimal parseString(String s) {
		// TODO Auto-generated method stub

		return new BigDecimal(s);
	}
	public static BigDecimal parseInt(int i) {
		// TODO Auto-generated method stub

		return new BigDecimal(i);
	}
	public static BigDecimal parseDouble(Double d) {
		// TODO Auto-generated method stub

		return new BigDecimal(d);
	}
	public static BigDecimal parseFloat(float f) {
		// TODO Auto-generated method stub

		return new BigDecimal(f);
	}

}
