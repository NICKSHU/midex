package web;

import init.Myjedis;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import redis.clients.jedis.Jedis;

import admin.Num;

import com.sun.xml.internal.ws.client.RequestContext;

import debtDebit.DebitOrder;
import debtDebit.Matching;

import exchange.Order;

       @Controller
   public class RegisterAction{
        public   int note=0;
        public   String user_list_item;
    @Autowired
    HttpServletRequest request;
	public RegisterAction(){
		//System.out.println("HelloAction()::" + this.hashCode());
	}
	@RequestMapping(value="/register.action")   
	public String register(Model model) throws Exception{
		   
		String clientCheckcode = request.getParameter("validateCode");//接收客户端浏览器提交上来的验证码
        String serverCheckcode = (String) request.getSession().getAttribute("checkcode");//从服务器端的session中取出验证码
        if (clientCheckcode.toUpperCase().equals(serverCheckcode.toUpperCase())) {//将客户端验证码和服务器端验证比较，如果相等，则表示验证通过
            
        	int note=0;
   	        Jedis jedis=Myjedis.getJedis();
        	System.out.println("验证码验证通过！");
            String userid= request.getParameter("userid");
            String name = request.getParameter("name");
            String passwd= request.getParameter("passwd");
            String repasswd= request.getParameter("repasswd");
            String email= request.getParameter("email");
            if(userid.trim().equals("")||name.trim().equals("")||
            		passwd.trim().equals("")||repasswd.trim().equals("")||
            		email.trim().equals("")){
            	
            	model.addAttribute("message","请将信息填写完整！");
            	return "register.jsp";
            	}else{
            if(passwd.equals(repasswd)){
            	note=0;
        		Set<String> user_list=jedis.keys("user:*");
        		for(String user_list_item:user_list){
        			if(jedis.hget(user_list_item, "id").equals(userid)){
        				note=1;
        			}
        		}
        		if(note==1){
        			
        			model.addAttribute("message","用户号码已经被占用请更换");
        			return  "register.jsp";
        			
        		}else
        		{
        			create.Create.create_user(name, passwd, email, userid, "0");
        			model.addAttribute("message","注册成功请牢记用户号和密码。");
        			return "login.jsp";
        		} 
            }
            else{
            	model.addAttribute("message","两次密码不一致！");
            	return "register.jsp";
            }  
            }
        }else {
        	model.addAttribute("message","验证码验证失败！<br/>");  
        	return "register.jsp";
        }
       // return "register.jsp";
	}
	
	
	
	/**
	 * 业务方法
	 * 只要是/bye.action的请求，都交由HelloAction对象中的bye()方法去处理
	 * http://pc-20170108pkhb:8080/springmvc-day02/bye.action
	 */
	/*@RequestMapping(value="/bye.action")   
	public String bye(Model model) throws Exception{
		System.out.println("HelloAction::hello()");
		model.addAttribute("message","再见");
		return "success";
	}*/
	@RequestMapping(value="/login.action")   
	public String login(Model model) throws Exception{
		   
		String clientCheckcode = request.getParameter("validateCode");//接收客户端浏览器提交上来的验证码
        String serverCheckcode = (String) request.getSession().getAttribute("checkcode");//从服务器端的session中取出验证码
        if (clientCheckcode.toUpperCase().equals(serverCheckcode.toUpperCase())) {//将客户端验证码和服务器端验证比较，如果相等，则表示验证通过
            
        	 
   	        Jedis jedis=Myjedis.getJedis();
        	System.out.println("验证码验证通过！");
            String userid= request.getParameter("userid");
            String passwd= request.getParameter("passwd");
            System.out.println(""+userid+passwd);
            Set<String> user_list=jedis.keys("user:*");

            note=0;
            
            
            
            for(String user_list_item_o:user_list){
            	
            	System.out.println(""+jedis.hget(user_list_item_o, "id"));
            	if( jedis.hget(user_list_item_o, "id").equals(userid)
    					&&jedis.hget(user_list_item_o,"password").equals(passwd)){
            		
            		user_list_item=user_list_item_o;
            		note=1;
            	}
            }

        	if( note==1){
        		
        		/*
        		request.getSession().setAttribute("userid", userid);
            	request.getSession().setAttribute("password", jedis.hget(user_list_item,"password"));
            	request.getSession().setAttribute("email", jedis.hget(user_list_item,"email"));
            	request.getSession().setAttribute("password", passwd);
            	request.getSession().setAttribute("password", passwd);
            	
            	return "";
            	System.out.println(jedis.hget(user_list_item, "name")+jedis.hget(user_list_item, "password")+jedis.hget(user_list_item, "id")+jedis.hget(user_list_item, "email"));
            	*/
        		String email=jedis.hget(user_list_item, "email");
        		String name=jedis.hget(user_list_item, "name");
        		request.getSession().setAttribute("userid", userid);
        		request.getSession().setAttribute("password", passwd);
        		request.getSession().setAttribute("email",email );
        		request.getSession().setAttribute("name", name);
        		//Set<String> asset_info_list=jedis.keys("asset_info_id:*");
        		/*Map<String, String> asset_map=new  HashMap<String, String>();
        		
        		for(String asset_info_item:asset_info_list){	
        			if(jedis.hget(asset_info_item, "user_id").equals(userid)){
        				asset_map.put(jedis.hget(asset_info_item, "asset_category"), jedis.hget(asset_info_item, "asset_amount"));
        				 
        			}
        			request.getSession().setAttribute("asset_map", asset_map);
        			
        		}*/
        		model.addAttribute("message","登陆成功<br/>");
        		return "user.jsp";
                
        	}
        	else{
                	model.addAttribute("message","密码验证失败！<br/>");  
                	return "login.jsp";
        	}
            
       
            
            
	
        }else {
        	model.addAttribute("message","验证码验证失败！<br/>");  
        	
        }
        return "login.jsp";
	}
	
	@RequestMapping(value="/transferx.action")
	public String transferx(Model model) throws Exception{
		String clientCheckcode = request.getParameter("validateCode");//接收客户端浏览器提交上来的验证码
        String serverCheckcode = (String) request.getSession().getAttribute("checkcode");//从服务器端的session中取出验证码
        if (clientCheckcode.toUpperCase().equals(serverCheckcode.toUpperCase())) {
		String from_id=(String) request.getSession().getAttribute("userid");
		String password=(String) request.getParameter("password");
		String to_id=(String)request.getParameter("to_id");
		String asset_category=(String)request.getParameter("asset_category");
		BigDecimal amount= Num.parseString( request.getParameter("amount") );
		if(from_id.trim().equals("")||password.trim().equals("")||to_id.trim().equals("")||asset_category.trim().equals("")){
			model.addAttribute("message","请填写完整");  
		}else{
		String result=remittance.Transfer.asset_transfer(from_id, to_id, asset_category, amount, password);	
		model.addAttribute("message",result);  
		}
		return "user2.jsp";
		}
        else{
        	model.addAttribute("message","验证码不正确");  
        	return "user2.jsp";
        }
		 
	  
	}
	@RequestMapping(value="/order.action")
	public String order(Model model) throws Exception{
		 
		String id=(String) request.getSession().getAttribute("userid");
		String password=(String) request.getSession().getAttribute("password");
		BigDecimal price=Num.parseString( request.getParameter("price"));
		BigDecimal  amount=Num.parseString( request.getParameter("amount"));
		String buy_sell=(String) request.getParameter("buy_sell");
		String asset=(String) request.getParameter("asset_category");
		System.out.println(id + password + price + amount + buy_sell + asset);
		//order_book("000", "sell", 1.12, 5, "bitcoin", "123456789");
		String mess=
		exchange.Order.order_book(id, buy_sell, price, amount, asset, password);
		/*try{
		exchange.Order.direct_matching(asset);
		exchange.Order.direct_matching(asset);
		exchange.Order.direct_matching(asset);
		exchange.Order.direct_matching(asset);
		exchange.Order.direct_matching(asset);
		}
		catch (Exception e){
			e.printStackTrace();
			return "user2.jsp";
		}*/
		model.addAttribute("message",mess);  
		return "user2.jsp";
		
		 
	  
	}
	
	@RequestMapping(value="/create.action")
	public String create(Model model) throws Exception{
		String id=(String) request.getParameter("id");
		
		if(id.equals("19941001")){
		create.Create.create();
		}
		return "index.jsp";
	}
//	@RequestMapping(value="/match.action")
//	public String match(Model model) throws Exception{
//		String id=(String) request.getParameter("id");
//		
//		if(id.equals("19941001")){
//		
//			for(int i = 0 ;i<=1000;i++){
//				 
//				exchange.Order.matching();
//		 
//			
//			}
//			
//			
//		}
//		return "index.jsp";
//	}
	

	@RequestMapping(value="/debitorder.action")
	public String debit_order (Model model) throws Exception{
		String id=(String) request.getSession().getAttribute("userid");
		String password=(String) request.getSession().getAttribute("password");
		BigDecimal interest=Num.parseString( request.getParameter("price"));
		BigDecimal  amount=Num.parseString( request.getParameter("amount"));
		String borrow_lend_note=(String) request.getParameter("b_s");
		String asset=(String) request.getParameter("asset_category");
		//System.out.println(id + password + price + amount + buy_sell + asset);
		String mess=DebitOrder.debit_order_book(id, borrow_lend_note, amount, asset, password, interest); 
		model.addAttribute("message",mess);  
		return "user2.jsp";
		 
	}
	
	
	@RequestMapping(value="/cancel.action")
	public String orderCancel(Model model) throws Exception{
		String asset_order=(String) request.getParameter("assetorder");
		String[] aso=asset_order.split("A");
		String password=(String) request.getSession().getAttribute("password");
		String mess=Order.order_cancel(aso[0], aso[1].replace("B", "\\$"), password);
		model.addAttribute("message",mess);  
		return "user2.jsp";
	}
	
	@RequestMapping(value="/cancel2.action")
	public String debit_orderCancel(Model model) throws Exception{
		String asset_order=(String) request.getParameter("assetorder");
		String[] aso=asset_order.split("A");
		String password=(String) request.getSession().getAttribute("password");
		String mess=DebitOrder.debit_order_cancel(aso[0], aso[1].replace("B", "\\$"), password);
		model.addAttribute("message",mess);  
		return "user2.jsp";
	}
	
	
	@RequestMapping(value="/quit.action")
	public String quit(Model model) throws Exception{
		 
		
		request.getSession().setAttribute("userid", "");
		request.getSession().setAttribute("password", "");
		request.getSession().setAttribute("email","" );
		request.getSession().setAttribute("name", "");
		
		model.addAttribute("message","安全退出成功");  
		return "user2.jsp";
	}
	
	
	
} 
	

